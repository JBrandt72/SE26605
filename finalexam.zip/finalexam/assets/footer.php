<?php
/**
 * Created by PhpStorm.
 * User: 005501496
 * Date: 12/11/2017
 * Time: 7:41 AM
 */

?>

</section>
</body>

<footer style="clear:both; text-align:center"">
Copyright &copy; <?php echo Date('Y'); ?> Jonathan Brandt. All rights reserved.
</footer>

</html>