<?php
/**
 * Created by PhpStorm.
 * User: 005501496
 * Date: 12/11/2017
 * Time: 7:41 AM
 */

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css" integrity="sha384-PsH8R72JQ3SOdhVi3uxftmaW6Vc51MKb0q5P2rRUpPvrszuE4W1povHYgTpBfshb" crossorigin="anonymous">

</head>
<body>
<header style="text-align:center">
    <h1>Mailing List</h1>
    <a href="index.php?action=Manage">Add Accounts</a> |
    <a href="index.php?action=View">View Accounts <sup></a>
</header>
<section class="container">